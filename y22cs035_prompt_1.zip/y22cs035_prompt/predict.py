import torch
from transformers import BertTokenizer, BertForSequenceClassification

# Load Model & Tokenizer
model_path = "./saved_model"
model = BertForSequenceClassification.from_pretrained(model_path)
tokenizer = BertTokenizer.from_pretrained(model_path)

def predict_text(text):
    inputs = tokenizer(text, padding="max_length", truncation=True, max_length=256, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**inputs)
    logits = outputs.logits
    prediction = torch.argmax(logits, dim=1).item()
    return "Positive" if prediction == 1 else "Negative"

if __name__ == "__main__":
    text = input("Enter a review: ")
    print("Prediction:", predict_text(text))
