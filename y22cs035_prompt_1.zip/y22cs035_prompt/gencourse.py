import requests
import json

# Available Free Models
FREE_MODELS = {
    "1": "mistralai/Mistral-7B-Instruct",
    "2": "tiiuae/falcon-7b-instruct",
    "3": "google/flan-t5-large"
}

def generate_questions(course, difficulty, question_type, num_questions, api_key, model_name):
    """Generates questions using the selected model"""
    prompt = f"Generate {num_questions} {question_type} questions on {course} at a {difficulty} level."
    
    response = requests.post(
        f"https://api-inference.huggingface.co/models/{model_name}",
        headers={"Authorization": f"Bearer {api_key}"},
        json={"inputs": prompt}
    )

    try:
        response_data = response.json()
        if response.status_code == 200:
            print("\n✅ Generated Questions:")
            print(response_data[0]['generated_text'])
        else:
            print("\n❌ Error:", response_data)
    except json.JSONDecodeError:
        print("\n❌ Error: No valid response received from the model.")

def simulate_answers(questions, student_level, api_key, model_name):
    """Simulates student answers based on given questions"""
    prompt = f"Answer these questions as a {student_level} student:\n{questions}"
    
    response = requests.post(
        f"https://api-inference.huggingface.co/models/{model_name}",
        headers={"Authorization": f"Bearer {api_key}"},
        json={"inputs": prompt}
    )

    try:
        response_data = response.json()
        if response.status_code == 200:
            print("\n✅ Simulated Student Answers:")
            print(response_data[0]['generated_text'])
        else:
            print("\n❌ Error:", response_data)
    except json.JSONDecodeError:
        print("\n❌ Error: No valid response received from the model.")

def main():
    """Main function to run the script"""
    api_key = input("🔑 Enter your Hugging Face API key: ")

    # Model Selection
    print("\n📌 Choose a Free Model:")
    for num, model in FREE_MODELS.items():
        print(f"{num}. {model}")
    model_choice = input("Enter model number: ")

    model_name = FREE_MODELS.get(model_choice)
    if not model_name:
        print("\n❌ Invalid choice. Exiting.")
        return

    # User Inputs
    course = input("\n📚 Enter the course (e.g., NLP, Machine Learning): ")
    difficulty = input("🎯 Choose difficulty level (easy, medium, hard): ").lower()
    question_type = input("📝 Choose question type (MCQ, descriptive, coding): ").lower()
    num_questions = int(input("🔢 Enter number of questions to generate: "))

    # Generate Questions
    generate_questions(course, difficulty, question_type, num_questions, api_key, model_name)

    # Simulate Answers
    choice = input("\n🤖 Do you want to simulate student answers? (yes/no): ").lower()
    if choice == 'yes':
        student_level = input("🎓 Choose student level (beginner, intermediate, advanced): ")
        questions = input("📄 Paste the generated questions here:\n")
        simulate_answers(questions, student_level, api_key, model_name)

if __name__ == "__main__":
    main()
