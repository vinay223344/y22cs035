import torch
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

# Load Dataset
dataset = load_dataset("imdb")
tokenizer = BertTokenizer.from_pretrained("prajjwal1/bert-tiny")

# Tokenization function
def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True, max_length=256)

# Apply tokenization
tokenized_datasets = dataset.map(tokenize_function, batched=True)
tokenized_datasets = tokenized_datasets.remove_columns(["text"])
tokenized_datasets = tokenized_datasets.rename_column("label", "labels")
tokenized_datasets.set_format("torch")

# Load Model
model = BertForSequenceClassification.from_pretrained("prajjwal1/bert-tiny", num_labels=2)

# Training Arguments
training_args = TrainingArguments(
    output_dir="./saved_model",
    num_train_epochs=3,  # Increased epochs
    per_device_train_batch_size=4,  # Smaller batch size
    per_device_eval_batch_size=4,
    evaluation_strategy="epoch",
    save_strategy="epoch",
    save_total_limit=1,
    learning_rate=2e-5,  # Lower learning rate
    logging_dir="./logs",
    logging_steps=10,
    load_best_model_at_end=True,  
)

# Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"],
    eval_dataset=tokenized_datasets["test"],
)

# Train Model
trainer.train()

# Save Model
model.save_pretrained("./saved_model")
tokenizer.save_pretrained("./saved_model")
