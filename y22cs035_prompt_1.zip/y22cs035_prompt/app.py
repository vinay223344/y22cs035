# import json
# import numpy as np
# from sentence_transformers import SentenceTransformer
# import faiss
# import os

# # Step 1: Load Embedding Model
# model = SentenceTransformer('all-MiniLM-L6-v2')

# # Step 2: Text Data
# text = """When __syncthreads is called, each thread in the same thread block must wait until all other threads in that thread block have reached this synchronization point. 
# All global and shared memory accesses made by all threads prior to this barrier will be visible to all other threads in the thread block after the barrier. The function is used to coordinate communication between threads in the same block, but it can negatively affect performance by forcing warps to become idle.
# Threads within a thread block can share data through shared memory and registers. When sharing data between threads you need to be careful to avoid race conditions. Race conditions, or hazards, are unordered accesses by multiple threads to the same memory location. 
# For example, a read-after-write hazard occurs when an unordered read of a location occurs following a write. Because there is no ordering between the read and the write, it is undefined if the read should have loaded the value of that location before the write or after the write.
# Other examples of hazards are write-after-read or write-after-write. While threads in a thread block run logically in parallel, not all threads can execute physically at the same time. 
# If thread A tries to read data that is written by thread B in a different warp, you can only be sure that thread B has finished writing if proper synchronization is used. Otherwise, a race condition occurs.
# There is no thread synchronization among different blocks. The only safe way to synchronize across blocks is to use the global synchronization point at the end of every kernel execution; 
# that is, terminate the current kernel and start a new kernel for the work to be performed after global synchronization."""

# # Step 3: Compute Embeddings
# embedding = model.encode([text])
# embedding = np.array(embedding, dtype=np.float32)

# # Step 4: Save Embeddings
# # Save as JSON
# with open("embeddings.json", "w") as json_file:
#     json.dump(embedding.tolist(), json_file)

# # Save as CSV
# np.savetxt("embeddings.csv", embedding, delimiter=",")

# # Save as NumPy .npy file
# np.save("embeddings.npy", embedding)

# print("\n✅ Embeddings saved successfully!")

# # Step 5: Load Embeddings
# # Load from JSON
# if os.path.exists("embeddings.json"):
#     with open("embeddings.json", "r") as json_file:
#         loaded_json = np.array(json.load(json_file))
#     print("\n✅ JSON Embeddings Loaded Successfully!")

# # Load from CSV (Fix applied)
# if os.path.exists("embeddings.csv"):
#     loaded_csv = np.atleast_2d(np.loadtxt("embeddings.csv", delimiter=","))
#     print("\n✅ CSV Embeddings Loaded Successfully!")

# # Load from NumPy .npy file
# if os.path.exists("embeddings.npy"):
#     loaded_npy = np.load("embeddings.npy")
#     print("\n✅ NPY Embeddings Loaded Successfully!")

# # Step 6: Print Results
# print("\n🔹 Loaded Embeddings (First 10 values from JSON):\n", loaded_json[0][:10])
# print("\n🔹 Loaded Embeddings (First 10 values from CSV):\n", loaded_csv[0][:10])
# print("\n🔹 Loaded Embeddings (First 10 values from NPY):\n", loaded_npy[0][:10])
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

# Step 1: Load Embedding Model
model = SentenceTransformer('all-MiniLM-L6-v2')  # Small but effective model

# Step 2: Text Data
text = """When __syncthreads is called, each thread in the same thread block must wait until all other threads in that thread block have reached this synchronization point. 
All global and shared memory accesses made by all threads prior to this barrier will be visible to all other threads in the thread block after the barrier. The function is used to coordinate communication between threads in the same block, but it can negatively affect performance by forcing warps to become idle.
Threads within a thread block can share data through shared memory and registers. When sharing data between threads you need to be careful to avoid race conditions. Race conditions, or hazards, are unordered accesses by multiple threads to the same memory location. 
For example, a read-after-write hazard occurs when an unordered read of a location occurs following a write. Because there is no ordering between the read and the write, it is undefined if the read should have loaded the value of that location before the write or after the write.
Other examples of hazards are write-after-read or write-after-write. While threads in a thread block run logically in parallel, not all threads can execute physically at the same time. 
If thread A tries to read data that is written by thread B in a different warp, you can only be sure that thread B has finished writing if proper synchronization is used. Otherwise, a race condition occurs.
There is no thread synchronization among different blocks. The only safe way to synchronize across blocks is to use the global synchronization point at the end of every kernel execution; 
that is, terminate the current kernel and start a new kernel for the work to be performed after global synchronization."""

# Store text mapping
text_mapping = {0: text}  # Store text with its corresponding index

# Step 3: Compute Embeddings
embedding = model.encode([text])  # Converts text into a vector
embedding = np.array(embedding, dtype=np.float32)  # Convert to NumPy array

# Step 4: Print Full Embedding Vector
print("\nGenerated Embeddings:\n", embedding[0])  # Print entire embedding vector

# Step 5: Store in FAISS
d = embedding.shape[1]  # Dimension of embeddings
index = faiss.IndexFlatL2(d)  # L2 similarity search
index.add(embedding)  # Add vector to FAISS index

# Step 6: Retrieve from FAISS
D, I = index.search(embedding, 1)  # Search for the most similar vector

# Step 7: Print Retrieval Results
print("\nStored Embedding Index:", I[0][0])
print("Distance Score:", D[0][0])

# Step 8: Retrieve Original Text
retrieved_index = I[0][0]
retrieved_text = text_mapping.get(retrieved_index, "Text not found")
print("\nRetrieved Text:\n", retrieved_text)
