import streamlit as st
from predict import predict_text

st.title("Movie Review Sentiment Analysis 🎬")

text_input = st.text_area("Enter your review:")

if st.button("Analyze Sentiment"):
    if text_input:
        result = predict_text(text_input)
        st.write(f"**Sentiment:** {result}")
    else:
        st.write("⚠️ Please enter some text.")
