import streamlit as st
from transformers import AutoModelForSequenceClassification, AutoTokenizer
import torch

# Load model & tokenizer
model_path = "./saved_model"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForSequenceClassification.from_pretrained(model_path)
model.eval()

# Streamlit UI
st.title("Movie Review Sentiment Classifier 🎬")
user_input = st.text_area("Enter your movie review:")

if st.button("Analyze Sentiment"):
    inputs = tokenizer(user_input, return_tensors="pt", padding=True, truncation=True)
    with torch.no_grad():
        outputs = model(**inputs)
    prediction = torch.argmax(outputs.logits, dim=1).item()
    sentiment = "Positive 😊" if prediction == 1 else "Negative 😞"
    st.write(f"**Sentiment:** {sentiment}")
